public class Main {
    public static void main(String[] args) throws Exception {
        Pilha<Integer> pilha1 = new Pilha<Integer>(10);
        for(int i=0;i<pilha1.getCapacidade();i++){
            pilha1.guarde(i);
            System.out.println(pilha1.toString());
        }
        for(int i=0;i<(pilha1.getCapacidade()-1);i++){
            pilha1.remova();
            System.out.println(pilha1.toString());
        }
        
    }
}
