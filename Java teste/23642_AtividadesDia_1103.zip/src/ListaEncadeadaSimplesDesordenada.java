import org.w3c.dom.Notation;




//Murilo dos Santos Cela | RA:23642
//caso você leia: Tem alguns rerros no código que eu não consegui consertar
//mas creio que a lógica esteja certa, deve ser erro de sintaxe e/ou 
//o metodo não enxergar a variável, porém parte do código foi feito em aula
//então não entendo que erros são esses.
//Tambem tem alguns error no return. EX: return atual;
//que eu também não compreendi.









public class ListaEncadeadaSimplesDesordenada<X> {
    private class No{
        private X info;
        private No prox;

        public No (X i, No p){
            this.info = i;
            this.prox = p;
        }

        public No(X i){
            this.info=i;
            this.prox=null;
        }

        public X getInfo(){
            return this.info;
        }

        public No getProx(){
            return this.prox;
        }
        public void setInfo(X i){
            this.info = i;
        }
        public void setProx(No p){
            this.prox = p;
        }

        //metodos obrigatórios da classe No

        @Override
        public String toString(){
            return ""+this.info.toString();
        }

        @Override
        public boolean equals(Object obj){
            if(obj==this) return true;//se for da classe No
            if(obj==null) return false;//se guardar valor nulo
            if(obj.getClass()!=this.getClass()) return false;//se as classes dos objetos não forem as mesmas
            if(!(No)obj.info().equals(this.info())) return false;//se o a informação do objeto for diferente da informação da classe No
            return true;
        }

        @Override
        public int hashCode(){
            int ret=1;
            ret=2*ret+this.getInfo().hashCode();
            if(ret<0) ret=-ret;
            return ret;
        }
        //a classe Clonador não existe
        public No (No modelo)throws Exception{
            if(modelo==null)throw Exception("modelo nulo");
            if(modelo.info() instanceof Cloneable){
                this.info = new Clonador<X>().clone(modelo.info);
            }
            else this.info = modelo.info;
        }
        public Object clone(){
            No ret=null;
            try{
                ret=new No(this);
            }
            catch(Exception erro){}//so da erro se rceber parametro nulo, e this numquinha é nulo
        }
    }

    private No primeiro =null;

    public void guadeNoInicio(X i){
        if (i==null)throw Exception("informação ausente");
        this.primeiro = new No (i, this.primeiro);
    }

    private No ultimo = null;
    public void guardaNoFinal(X i) throws Exception{
        if(i==null)throw new Exception("informação ausente");
        No atual = this.primeiro;
        while(atual.getProx()!=null){
            atual=atual.getProx();
        }
        this.ultimo = new No (i);
        atual.setProx(new No(i));
    }

    public boolean tem (X i){
        No atual=this.primeiro;
        while(atual!=null){
            if(atual.info.equals(i))return true;
            atual = atual.getProx();
        }
        return false;
    }

    @Override
    public String toString(){
        String ret="[";
        if (this.primeiro==null) return "[]";
        ret=(String)this.primeiro.getInfo();
        No atual = this.primeiro.getProx();
        while (atual!=null) {
            ret+=", "+atual.getInfo();
            atual=atual.getProx();
        }
        return ret+"]";
    }

    //parei no metodo equals-------------------------------
    //terminar os metodos obrigatórios e o código do Notion
    //depois seguir para os exercicios.
    public boolean equals (Object obj){
        if(obj==null) return false;
        if(obj==this) return true;
        if(obj.getClass()!=this.getClass()) return false;

        No atualDoThis = this.primeiro;
        No atualdoObj = ((ListaEncadeadaSimplesDesordenada<X>)obj).primeiro;

        while(atualDoThis != null && atualdoObj != null)return false;
        return true;
    }

    public int hashCode(){
        int ret=1;

        No atual=this.primeiro;
        while(atual!=null){
            ret=ret*2+atual.getInfo().hashCode();
            atual=atual.getProx();
        }

        if(ret<0) ret=-ret;
        return ret;
    }

    public ListaEncadeadaSimplesDesordenada(ListaEncadeadaSimplesDesordenada<X> modelo)throws Exeprion{
        if(modelo==null) throw new Exeption("modelo ausente");
        if(modelo.primeiro==null){
            this.primeiro=null;
            return;
        }
        this.primeiro=new No(modelo.primeiro.getInfo());
        No atualDoThis = this.primeiro;
        No atualdoModelo = modelo.primeiro.getProx();

        while (atualdoModelo!=null){
            atualDoThis.setProx(new No (atualdoModelo.getInfo()));
            atualDoThis = atualDoThis.getProx();
            atualdoModelo = atualdoModelo.getProx();
        }
    }

    public Object clone(){
        ListaEncadeadaSimplesDesordenada<X> ret=null;

        try{
            ret= new ListaEncadeadaSimplesDesordenada(this);
        }catch (Exception erro){}
        return ret;
    }

    //6) public void remova (int posicao) thows Exception
    public void removaPrimeiro() throws Exception
    {
        this.primeiro= primeiro.getProx();//atributo primeiro como "o segund item da lista", ou seja o primeiro passaa ser o próximo número
    }

    //5) public void removaUltimo () thows Exception
    public void removaUltimo() throws Exception
    {
        No atual = this.primeiro;
        while(atual.getProx()!=null){
            atual = atual.getProx();
        }
        atual=null;
    }

    //1) public X getPrimeiro () thows Exception

    public X getPrimeiro() throws Exception{
         return this.primeiro;
    }

    //2) public X getUltimo () thows Exception
    public X getUltimo()throws Exception{
        No atual = this.primeiro;
        while(atual.getProx()!=null){
            atual=atual.getProx();
        }
        return atual;
    }

    //3) public X get (int posicao) thows Exception
    public X get (int posicao) throws Exception{
        No atual = this.primeiro;
        int cout = 0;
        //tamanho da lista
        while(atual.getProx()!=null){
            cout++;
            atual = atual.getProx();
        }
        //vai até a posição
        int index =0;
        atual= this.primeiro;
        if(posicao > cout || posicao < cout)throw new Exception("posição fora do escopo");

        while(index<posicao){
            atual.getProx()
            index++;
        }
        return atual;
    }

    //4) public void removaPrimeiro () thows Exception
    public void remova(int posicao)throws Exception{
        No atual = this.primeiro;
        int cout = 0;
        while (atual.getProx()!=null) {
            atual=atual.getProx();
            cout++;
        }
        int index = 0;
        atual=this.primeiro;
        if(posicao > cout || posicao < cout)throw new Exception("posição fora do escopo");
        while(index<posicao){
            atual.getProx();
            index++;
        }
        return atual;
    }

    public ListaEncadeadaSimplesDesordenada(ListaEncadeadaSimplesDesordenada<X> modelo) throws Exception{
        if(modelo==null) throw new Exception("modelo ausente");
        if(modelo.primeiro==null){
            this.primeiro=null;
            return;
        this.primeiro=new No(modelo.primeiro.getInfo());
        No atualDoThis = this.primeiro;
        No atualdoModelo = modelo.primeiro.getProx();

        while(atualdoModelo!=null){
            atualDoThis.setProx(new No (atualdoModelo.getInfo()));
            atualDoThis = atualDoThis.getProx();
            atualdoModelo = atualdoModelo.getProx();
        }
    }
    }
}
