public class Main {
    public void main(String[] args)
    {
        ArvoreBinariaDeBusca<Integer> arvore = new ArvoreBinariaDeBusca();
    }
}
